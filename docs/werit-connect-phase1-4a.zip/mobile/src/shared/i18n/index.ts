import * as Localization from 'expo-localization';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import de from './locales/de.json';
import en from './locales/en.json';
import fr from './locales/fr.json';

/** Unterstützte Sprachen. Weitere Sprachen: Sprachdatei anlegen und hier eintragen. */
export const SUPPORTED_LANGUAGES = ['de', 'en', 'fr'] as const;
export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number];

export const FALLBACK_LANGUAGE: SupportedLanguage = 'de';

export function isSupportedLanguage(code: string | null | undefined): code is SupportedLanguage {
  return !!code && (SUPPORTED_LANGUAGES as readonly string[]).includes(code);
}

function deviceLanguage(): SupportedLanguage {
  const code = Localization.getLocales()[0]?.languageCode;
  return isSupportedLanguage(code) ? code : FALLBACK_LANGUAGE;
}

void i18n.use(initReactI18next).init({
  resources: { de: { translation: de }, en: { translation: en }, fr: { translation: fr } },
  lng: deviceLanguage(),
  fallbackLng: FALLBACK_LANGUAGE,
  interpolation: { escapeValue: false },
  returnNull: false,
});

export default i18n;
