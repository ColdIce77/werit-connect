import type { AppRole, Permission } from '../permissions';

/**
 * Vertrag zwischen App und API (Phase 5 setzt ihn im Backend um).
 * Texte liefert das Backend bereits in der Sprache aus dem Header Accept-Language.
 * Zeitangaben sind ISO-8601-Zeichenketten in UTC.
 */

export interface MeResponse {
  user: {
    id: string;
    displayName: string;
    email: string;
    language: string;
  };
  roles: AppRole[];
  permissions: Permission[];
}

export type PostType = 'news' | 'announcement';
export type PostPriority = 'normal' | 'important';

export interface Post {
  id: string;
  type: PostType;
  priority: PostPriority;
  title: string;
  summary: string | null;
  body: string;
  imageUrl: string | null;
  authorName: string | null;
  publishAt: string;
}

export type TaskStatus = 'open' | 'done' | 'cancelled';

export interface Task {
  id: string;
  title: string;
  description: string | null;
  dueAt: string | null;
  status: TaskStatus;
}

export interface BirthdayEntry {
  userId: string;
  displayName: string;
  day: number;
  month: number;
  isToday: boolean;
}

export interface NewHire {
  userId: string;
  displayName: string;
  jobTitle: string | null;
  departmentName: string | null;
  hireDate: string;
}

export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';

export interface TicketSummary {
  id: string;
  title: string;
  status: TicketStatus;
  updatedAt: string;
}

export interface DashboardResponse {
  announcements: Post[];
  news: Post[];
  tasks: Task[];
  birthdays: BirthdayEntry[];
  newHires: NewHire[];
  openTickets: { count: number; items: TicketSummary[] };
}

export interface Employee {
  id: string;
  displayName: string;
  jobTitle: string | null;
  departmentName: string | null;
  locationName: string | null;
  email: string;
  phoneOffice: string | null;
  phoneMobile: string | null;
  managerId: string | null;
  managerName: string | null;
}
