import { keepPreviousData, useQuery } from '@tanstack/react-query';

import { api } from '../../shared/api/client';
import type { Employee } from '../../shared/api/types';

/**
 * Online-Zugriff auf das Verzeichnis. Für die Offline-Suche (SQLite mit FTS5, Delta-Sync)
 * ersetzt eine lokale Datenquelle diese Funktionen. Die Bildschirme bleiben unverändert.
 */
export const directoryKeys = {
  search: (query: string) => ['directory', 'search', query] as const,
  employee: (id: string) => ['directory', 'employee', id] as const,
};

export function useDirectorySearch(query: string) {
  return useQuery({
    queryKey: directoryKeys.search(query),
    queryFn: ({ signal }) =>
      api.get<Employee[]>('/directory', { query: { q: query, limit: 50 }, signal }),
    placeholderData: keepPreviousData,
  });
}

export function useEmployee(id: string) {
  return useQuery({
    queryKey: directoryKeys.employee(id),
    queryFn: ({ signal }) => api.get<Employee>(`/directory/${id}`, { signal }),
  });
}
